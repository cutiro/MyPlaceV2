package com.myplace.biz.member.impl;

public class UserHomeServiceImpl implements UserHomeService {

}
