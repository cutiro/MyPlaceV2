package com.myplace.biz.member.impl;

public interface UserHomeService {

}
